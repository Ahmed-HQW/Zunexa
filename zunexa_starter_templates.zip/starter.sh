#!/usr/bin/env bash
# Zunexa Free Starter Template — shell script
set -euo pipefail

echo "Zunexa starter script running ✦"
