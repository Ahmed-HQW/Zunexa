// Zunexa Free Starter Template — vanilla JS, no dependencies
document.addEventListener('DOMContentLoaded', () => {
  const app = document.getElementById('app');
  const box = document.createElement('div');
  box.textContent = 'جاهز للبناء — عدّل هذا الملف وابدأ 🚀';
  box.style.cssText = 'padding:20px;border:1px solid #D4AF37;border-radius:10px;text-align:center';
  app.appendChild(box);
});
